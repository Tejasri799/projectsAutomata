package STEP_DEF;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class STEP_DEF {
	@Given("^Browser is launched and home page displayed$")
	public void browser_is_launched_and_home_page_displayed() throws Throwable {
	  
	}

	@When("^User enters register credentials and clicks on submit$")
	public void user_enters_register_credentials_and_clicks_on_submit() throws Throwable {
	
	}

	@Then("^Registration is successful & profile name displayed correctly$")
	public void registration_is_successful_profile_name_displayed_correctly() throws Throwable {
	    
	}


}
