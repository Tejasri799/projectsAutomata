package Runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="src\\main\\resources\\Feature",glue="STEP_DEF")

public class TestRunner extends AbstractTestNGCucumberTests{

}