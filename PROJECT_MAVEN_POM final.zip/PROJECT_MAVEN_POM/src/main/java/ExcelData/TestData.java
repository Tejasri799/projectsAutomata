package ExcelData;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TestData {
	public class Excel_1 {

		public static String[][] data;
		public static int Row;
		public static String filename="C:\\Users\\BLTuser.BLT0188\\Desktop\\TT.xlsx";
		   public static void getExcel(String sheet){
		  data= new String[2][3];
		    File f= new File(filename);
		    for(int Row=1;Row<=2;Row++){
		  try {
		FileInputStream fis= new FileInputStream(f);
		XSSFWorkbook w=new XSSFWorkbook(fis);
		XSSFSheet s=w.getSheet(sheet);
		XSSFRow r=s.getRow(Row);
		for(int column=0;column<=2;column++){
		XSSFCell c=r.getCell(column);
		data[Row-1][column]=c.getStringCellValue();
		}
		   } catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		  catch (IOException e)
		  		{
			  		// TODO Auto-generated catch block
			  		e.printStackTrace();
				}
		    }
	   }
}


}
