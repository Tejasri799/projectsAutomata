package Library;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Utilities {
	WebDriver dr;
	public Utilities(WebDriver dr)
	{
		this.dr = dr;
	}
	public WebElement WE(By locator, int timeout)
	{
		WebElement u = null;
		try
		{
			WebDriverWait wait = new WebDriverWait(dr,timeout);
			u = wait.until(
					ExpectedConditions.visibilityOfElementLocated(locator)
					);
			System.out.println("Element found");
		}
		catch(Exception e2)
		{
			System.out.println("Element not found" + e2);
		}
		return u;
	}
	public WebElement ETBC(By locator,int timeout)
	{
		try {
			WebDriverWait wait = new WebDriverWait(dr,timeout);
			WebElement w = wait.until(
					ExpectedConditions.elementToBeClickable(locator)
					);
			System.out.println("Element found");
		}
		catch(Exception e1)
		{
			System.out.println("Element not found" +e1);
		}
		return null;
	}
	public WebDriver bb(String b)
	{
		if(b=="Chrome")
		{
			System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
			dr = new ChromeDriver();

		}
		else if (b=="firefox")
		{
			System.setProperty("webdriver.gecko.driver","geckodriver.exe");
			dr = new FirefoxDriver();

		dr.get("https://www.selenium.dev/");
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		return dr;
	}
		return dr;
	}
}
